package com.android.support;
import android.content.Context;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
public class FloatingWindowManager {
    private Context context;
    private WindowManager windowManager;
    private View rootView;
    private WindowManager.LayoutParams params;
    private float startY = 0;
    private boolean isHidden = false;
    public FloatingWindowManager(Context context) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100; params.y = 100;
    }
    public void setView(View view) {
        this.rootView = view;
        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getPointerCount() == 3) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN: startY = event.getY(); break;
                        case MotionEvent.ACTION_UP:
                            float deltaY = event.getY() - startY;
                            if (deltaY > 200 && !isHidden) {
                                rootView.setVisibility(View.GONE); isHidden = true;
                            } else if (deltaY < -200 && isHidden) {
                                rootView.setVisibility(View.VISIBLE); isHidden = false;
                            }
                            break;
                    }
                    return true;
                }
                return false;
            }
        });
        windowManager.addView(rootView, params);
    }
}
